import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdvancesolutionComponent } from './advancesolution/advancesolution.component';
import { HomeComponent } from './home/home.component';
import { OurproductComponent } from './ourproduct/ourproduct.component';
import { ManagedserviceComponent } from './managedservice/managedservice.component';


const routes: Routes = [
  {path:'home', component:HomeComponent},
  {path:'advancesolution', component:AdvancesolutionComponent},
  {path:'ourProductComponent', component:OurproductComponent},
  {path:'managedServiceComponent', component:ManagedserviceComponent},
  { path: '', redirectTo: '/home', pathMatch: 'full' }

];

@NgModule({
  declarations:[
    AdvancesolutionComponent,
    HomeComponent,
    OurproductComponent,
    ManagedserviceComponent

  ],
  imports: [
    RouterModule.forRoot(routes)
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
