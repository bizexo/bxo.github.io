import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-advancesolution',
  templateUrl: './advancesolution.component.html',
  styleUrls: ['./advancesolution.component.scss']
})
export class AdvancesolutionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
