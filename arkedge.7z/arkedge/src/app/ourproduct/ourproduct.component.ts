import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ourproduct',
  templateUrl: './ourproduct.component.html',
  styleUrls: ['./ourproduct.component.scss']
})
export class OurproductComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
