import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FooterComponent } from './footer/footer.component';
import { HeaderComponent } from './header/header.component';
// import { HomeComponent } from './home/home.component';
// import { OurproductComponent } from './ourproduct/ourproduct.component';
// import { AdvancesolutionComponent } from './advancesolution/advancesolution.component';
// import { ManagedserviceComponent } from './managedservice/managedservice.component';

@NgModule({
  declarations: [
    AppComponent,
    FooterComponent,
    HeaderComponent,
    // HomeComponent,
    // OurproductComponent,
    // AdvancesolutionComponent,
    // ManagedserviceComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
